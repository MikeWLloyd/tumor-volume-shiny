library(testthat)
library(txtq)

test_check("txtq")
