#ifndef __NLOPTR_H__
#define __NLOPTR_H__

#include <R.h>
#include <Rinternals.h>  // Rdefines.h is no longer maintained.

SEXP NLoptR_Optimize(SEXP args);

#endif /*__NLOPTR_H__*/
