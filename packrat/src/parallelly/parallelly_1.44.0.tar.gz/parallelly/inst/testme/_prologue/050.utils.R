## Local functions for test scripts
printf <- function(...) cat(sprintf(...))
