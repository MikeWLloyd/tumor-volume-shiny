# gh_set_endpoint() refuses to substitute an NA

    Code
      gh_set_endpoint(input)
    Condition
      Error in `gh_set_endpoint()`:
      ! Named NA parameters are not allowed: org

# gh_make_request() errors if unknown verb

    Unknown HTTP verb: "GEEET"

