# named NA is error

    Code
      check_named_nas(tc)
    Condition
      Error in `check_named_nas()`:
      ! Named NA parameters are not allowed: `a`

---

    Code
      check_named_nas(tc)
    Condition
      Error in `check_named_nas()`:
      ! Named NA parameters are not allowed: `a`

---

    Code
      check_named_nas(tc)
    Condition
      Error in `check_named_nas()`:
      ! Named NA parameters are not allowed: `c`

