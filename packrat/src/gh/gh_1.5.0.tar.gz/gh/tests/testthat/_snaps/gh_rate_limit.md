# errors

    Code
      gh_rate_limit(list())
    Condition
      Error in `gh_rate_limit()`:
      ! inherits(response, "gh_response") is not TRUE
    Code
      gh_rate_limits(.token = "bad")
    Condition
      Error in `gh()`:
      ! GitHub API error (401): Bad credentials
      i Read more at <https://docs.github.com/rest>

