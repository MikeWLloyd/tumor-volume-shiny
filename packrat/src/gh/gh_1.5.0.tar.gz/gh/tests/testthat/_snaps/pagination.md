# can extract relative pages

    Code
      gh_prev(page1)
    Condition
      Error in `gh_link_request()`:
      ! No prev page

