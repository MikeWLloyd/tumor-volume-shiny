# has_compiler_colored_diagnostics

    Code
      has_compiler_colored_diagnostics()
    Condition
      Error in `cache_exists()`:
      ! nope

