library(survival)
data('cancer')
