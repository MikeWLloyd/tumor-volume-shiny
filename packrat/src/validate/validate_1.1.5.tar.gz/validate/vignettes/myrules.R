
# basic range checks
speed >= 0
dist  >= 0

# ratio check
speed / dist <= 1.5


