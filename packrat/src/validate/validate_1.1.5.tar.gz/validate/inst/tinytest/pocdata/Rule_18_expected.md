
The file Rule_18HOUSEHOLDS.csv is 
- consistent with Rule_18PERSONS_valid.csv
- inconsistent with Rule_18PERSONS_invalid.csv


