# get_quarto_version

    Code
      get_quarto_version()
    Output
      [1] "NA"

---

    Code
      get_quarto_version()
    Output
      [1] "1.3.450 @ /path/to/quarto"

