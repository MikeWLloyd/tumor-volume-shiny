testme <- as.environment("testme")
loadNamespace(testme[["package"]])
