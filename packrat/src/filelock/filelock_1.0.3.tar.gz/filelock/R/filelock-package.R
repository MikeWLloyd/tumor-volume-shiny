#' @keywords internal
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
