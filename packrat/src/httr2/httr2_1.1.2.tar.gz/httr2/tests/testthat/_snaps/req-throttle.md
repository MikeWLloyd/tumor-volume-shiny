# throttling affects request performance

    Code
      time <- system.time(req_perform(req))[[3]]
    Message
      > Waiting 0.15s for throttling delay

