# addConnectServer is deprecated

    Code
      addConnectServer(url, quiet = TRUE)
    Condition
      Warning:
      `addConnectServer()` was deprecated in rsconnect 1.0.0.
      i Please use `addServer()` instead.

