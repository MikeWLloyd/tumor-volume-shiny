library(testthat)
library(rsconnect)

test_check("rsconnect")
