# handles CoC and SUPPORT if present

    <div class='community'>
    <h2 data-toc-skip>Community</h2>
    <ul class='list-unstyled'>
    <li><a href='CODE_OF_CONDUCT.html'>Code of conduct</a></li>
    <li><a href='SUPPORT.html'>Getting help</a></li>
    </ul>
    </div>

