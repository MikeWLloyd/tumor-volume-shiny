# renames src/ files

    Code
      rename_files("foo", "bar")
    Message
      v Moving 'src/foo.c' and 'src/foo.h' to 'src/bar.c' and 'src/bar.h'.

