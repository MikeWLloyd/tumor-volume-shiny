# write_union() messaging is correct with weird working directory

    Code
      write_union(proj_path("somefile"), letters[4:6])
    Message
      v Adding "d", "e", and "f" to 'somefile'.

