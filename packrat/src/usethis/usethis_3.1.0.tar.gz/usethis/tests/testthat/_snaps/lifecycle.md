# use_lifecycle() imports badges

    Code
      use_lifecycle()
    Message
      v Adding lifecycle to 'Imports' field in DESCRIPTION.
      [ ] Refer to functions with `lifecycle::fun()`.
      v Adding "@importFrom lifecycle deprecated" to 'R/{TESTPKG}-package.R'.
      v Writing 'NAMESPACE'.
      v Creating 'man/figures/'.
      v Copied SVG badges to 'man/figures/'.
      [ ] Add badges in documentation topics by inserting a line like this:
        #' `r lifecycle::badge('experimental')`
        #' `r lifecycle::badge('superseded')`
        #' `r lifecycle::badge('deprecated')`

