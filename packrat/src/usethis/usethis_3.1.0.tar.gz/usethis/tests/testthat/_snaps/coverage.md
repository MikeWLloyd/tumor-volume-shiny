# we use specific URLs in a codecov badge

    Code
      use_codecov_badge("OWNER/REPO")
    Message
      ! Can't find a README for the current project.
      i See `usethis::use_readme_rmd()` for help creating this file.
      i Badge link will only be printed to screen.
      [ ] Copy and paste the following lines into 'README':
        <!-- badges: start -->
        [![Codecov test coverage](https://codecov.io/gh/OWNER/REPO/graph/badge.svg)](https://app.codecov.io/gh/OWNER/REPO)
        <!-- badges: end -->

